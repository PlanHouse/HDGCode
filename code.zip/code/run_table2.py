import argparse
import json
from dataclasses import replace
from pathlib import Path

from hog_rnn.config import load_config
from hog_rnn.experiment import run_experiment


DATASETS = ("lorenz", "rossler", "four_wing", "yahoo", "etth1", "electricity", "traffic")
HORIZONS = (1, 5, 10, 20, 50)
ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", choices=DATASETS, nargs="*")
    parser.add_argument("--horizon", choices=HORIZONS, type=int, nargs="*")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    datasets = tuple(args.dataset) if args.dataset else DATASETS
    horizons = tuple(args.horizon) if args.horizon else HORIZONS
    for dataset in datasets:
        base = load_config(ROOT / "configs" / f"{dataset}.yaml")
        for horizon in horizons:
            config = replace(
                base,
                name=f"{dataset}_K3_H{horizon}_seed2025",
                data=replace(base.data, horizon=horizon),
                training=replace(base.training, seeds=[2025]),
            )
            result = run_experiment(config, resume=args.resume)
            print(json.dumps({
                "dataset": dataset,
                "horizon": horizon,
                "rmse": result["rmse_mean"],
                "mae": result["mae_mean"],
            }))


if __name__ == "__main__":
    main()
