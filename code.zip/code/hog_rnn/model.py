from typing import Optional, Sequence
import math
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F

from .reservoir import canonical_family, member_block_mask


def fixed_orthogonal_matrix(dimension: int, seed: int) -> torch.Tensor:
    state = torch.random.get_rng_state()
    torch.manual_seed(seed + 1)
    try:
        matrix = torch.empty(dimension, dimension)
        nn.init.orthogonal_(matrix)
    finally:
        torch.random.set_rng_state(state)
    return matrix


def expand_screening_masks(masks: Sequence[np.ndarray], hidden_dim: int, seed: int) -> tuple[torch.Tensor, torch.Tensor]:
    if not masks:
        raise ValueError("at least one lag mask is required")
    variables = masks[0].shape[1]
    rng = np.random.default_rng(seed)
    expanded = []
    for mask in masks:
        if mask.shape[1] != variables:
            raise ValueError("all masks must have the same variable count")
        family = canonical_family(tuple(tuple(np.flatnonzero(row).tolist()) for row in mask if np.any(row)))
        expanded.append(member_block_mask(family, hidden_dim, variables))
    support = np.stack(expanded).astype(np.float32)
    initial = rng.uniform(-1.0, 1.0, size=support.shape).astype(np.float32) * support
    return torch.from_numpy(support), torch.from_numpy(initial)


class SharedLagAttention(nn.Module):
    def __init__(self, hidden_dim: int, lags: int, embedding_dim: int = 8, scorer_dim: Optional[int] = None):
        super().__init__()
        scorer_dim = scorer_dim or max(1, math.ceil(hidden_dim / 4))
        self.lags = lags
        self.embedding = nn.Embedding(lags, embedding_dim)
        self.first = nn.Linear(2 * hidden_dim + embedding_dim, scorer_dim)
        self.second = nn.Linear(scorer_dim, 1)

    def forward(self, encoded: torch.Tensor) -> torch.Tensor:
        context = encoded.mean(dim=0)
        features = encoded.permute(1, 2, 0, 3)
        batch, steps = context.shape[:2]
        positions = self.embedding(torch.arange(self.lags, device=encoded.device))
        positions = positions.view(1, 1, self.lags, -1).expand(batch, steps, -1, -1)
        context = context.unsqueeze(2).expand(-1, -1, self.lags, -1)
        scores = self.second(F.relu(self.first(torch.cat((features, context, positions), dim=-1)))).squeeze(-1)
        return torch.softmax(scores, dim=-1)


class HOGRNN(nn.Module):
    def __init__(self, variables: int, hidden_dim: int, horizon: int, masks: Sequence[np.ndarray], seed: int,
                 leak: float = 0.5, initialization_scale: float = 0.1,
                 lag_attention_hidden_dim: Optional[int] = None, lag_attention_embedding_dim: int = 8):
        super().__init__()
        self.variables = variables
        self.hidden_dim = hidden_dim
        self.lags = len(masks)
        self.leak = leak
        support, initial = expand_screening_masks(masks, hidden_dim, seed)
        self.register_buffer("input_masks", support)
        self.register_buffer("initial_zero_mask", support == 0)
        self.input_weights = nn.Parameter(initial * initialization_scale)
        self.input_bias = nn.Parameter(torch.zeros(self.lags, hidden_dim))
        self.recurrent_weight = nn.Parameter(fixed_orthogonal_matrix(hidden_dim, seed), requires_grad=False)
        self.recurrent_bias = nn.Parameter(torch.zeros(hidden_dim))
        self.gain = SharedLagAttention(hidden_dim, self.lags, lag_attention_embedding_dim, lag_attention_hidden_dim)
        self.output = nn.Linear(hidden_dim, horizon)

    def forward(self, x: torch.Tensor, return_diagnostics: bool = False):
        if x.ndim != 3 or x.shape[-1] != self.variables:
            raise ValueError("x must have shape batch x time x variables")
        batch, steps, _ = x.shape
        encoded = []
        for lag in range(self.lags):
            shift = lag + 1
            delayed = torch.cat((torch.zeros(batch, shift, self.variables, device=x.device, dtype=x.dtype), x[:, :-shift]), dim=1)
            encoded.append(F.linear(delayed, self.input_weights[lag], self.input_bias[lag]))
        encoded = torch.stack(encoded)
        gains = self.gain(encoded)
        combined = torch.einsum("kbth,btk->bth", encoded, gains)
        state = torch.zeros(batch, self.hidden_dim, device=x.device, dtype=x.dtype)
        for index in range(steps):
            proposal = torch.tanh(F.linear(state, self.recurrent_weight, self.recurrent_bias) + combined[:, index])
            state = (1.0 - self.leak) * proposal + self.leak * state
        prediction = self.output(state)
        if return_diagnostics:
            return prediction, {"gains": gains, "effective_input_weights": self.input_weights}
        return prediction

    @torch.no_grad()
    def structure_diagnostics(self) -> dict[str, float]:
        selected = self.input_weights[~self.initial_zero_mask]
        unselected = self.input_weights[self.initial_zero_mask]
        return {"selected_l1": float(selected.abs().mean()) if selected.numel() else 0.0, "unselected_l1": float(unselected.abs().mean()) if unselected.numel() else 0.0, "unselected_nonzero_fraction": float((unselected.abs() > 1e-12).float().mean()) if unselected.numel() else 0.0}

    @torch.no_grad()
    def recurrent_diagnostics(self) -> dict[str, float]:
        weight = self.recurrent_weight.detach().float()
        identity = torch.eye(weight.shape[0], dtype=weight.dtype, device=weight.device)
        error = torch.linalg.matrix_norm(weight.T @ weight - identity) / torch.sqrt(torch.tensor(float(weight.shape[0]), dtype=weight.dtype, device=weight.device))
        return {"orthogonality_relative_fro_error": float(error)}
