from __future__ import annotations

import numpy as np


def forecast_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, object]:
    error = np.asarray(y_pred, dtype=float) - np.asarray(y_true, dtype=float)
    if error.shape != np.asarray(y_true).shape:
        raise ValueError("prediction and target shapes differ")
    denominator = np.maximum(np.abs(np.asarray(y_true, dtype=float)), 1e-8)
    mape = 100.0 * np.mean(np.abs(error) / denominator)
    return {
        "rmse": float(np.sqrt(np.mean(error ** 2))),
        "mae": float(np.mean(np.abs(error))),
        "mape": float(mape),
        "rmse_by_horizon": np.sqrt(np.mean(error ** 2, axis=0)).tolist(),
        "mae_by_horizon": np.mean(np.abs(error), axis=0).tolist(),
        "mape_by_horizon": (100.0 * np.mean(np.abs(error) / denominator, axis=0)).tolist(),
    }


def aggregate(records: list[dict[str, float]], keys: tuple[str, ...] = ("rmse", "mae", "mape")) -> dict[str, float]:
    result: dict[str, float] = {}
    for key in keys:
        values = np.asarray([record[key] for record in records], dtype=float)
        result[f"{key}_mean"] = float(values.mean())
        result[f"{key}_std"] = float(values.std(ddof=1)) if len(values) > 1 else 0.0
    return result

