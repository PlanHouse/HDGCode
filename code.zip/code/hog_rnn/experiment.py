from dataclasses import asdict, replace
from pathlib import Path
import json
import pandas as pd
import torch

from .data import chronological_split, load_series, make_windows, screening_pairs
from .io import environment, sha256, write_json
from .metrics import aggregate
from .model import HOGRNN
from .screening import screen_all_lags, serializable_screening
from .training import fit, set_seed


def parameter_counts(model: torch.nn.Module) -> dict[str, int]:
    return {"trainable_parameters": sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad), "total_parameters": sum(parameter.numel() for parameter in model.parameters())}


def prepare(config):
    values = load_series(config.data)
    split = chronological_split(values, config.data)
    train_xy = make_windows(split.train, config.data.sequence_length, config.data.horizon, config.data.target)
    validation_xy = make_windows(split.validation, config.data.sequence_length, config.data.horizon, config.data.target)
    test_xy = make_windows(split.test, config.data.sequence_length, config.data.horizon, config.data.target)
    return values, split, train_xy, validation_xy, test_xy


def build_summary(config, values, split, train_xy, validation_xy, test_xy, rows, screening_records, status):
    metrics = aggregate([{key: float(row[key]) for key in ("rmse", "mae", "mape")} for row in rows]) if rows else {}
    return {"name": config.name, "status": status, **metrics, "runs": len(rows), "completed_seeds": [int(row["seed"]) for row in rows], "expected_seeds": config.training.seeds, "screening_seconds_total": float(sum(item["seconds"] for item in screening_records)), "screening_evaluations_total": int(sum(item["evaluations"] for item in screening_records)), "screening_by_seed": screening_records, "data_sha256": sha256(config.data.path), "data_shape": list(values.shape), "split_lengths": {"train": len(split.train), "validation": len(split.validation), "test": len(split.test)}, "window_counts": {"train": len(train_xy[0]), "validation": len(validation_xy[0]), "test": len(test_xy[0])}, "normalization_minimum": split.minimum, "normalization_scale": split.scale, "environment": environment(), "config": config.to_dict()}


def run_experiment(config, resume: bool = False) -> dict:
    output = Path(config.output_dir) / config.name
    output.mkdir(parents=True, exist_ok=True)
    values, split, train_xy, validation_xy, test_xy = prepare(config)
    write_json(output / "run_manifest.json", {"name": config.name, "data_sha256": sha256(config.data.path), "data_shape": list(values.shape), "config": config.to_dict(), "environment": environment()})
    raw_path = output / "raw_runs.csv"
    rows = pd.read_csv(raw_path).to_dict("records") if resume and raw_path.exists() else []
    completed = {int(row["seed"]) for row in rows}
    progress = output / "progress.json"
    previous = json.loads(progress.read_text(encoding="utf-8")) if resume and progress.exists() else {}
    screening_records = previous.get("screening_by_seed", [])
    screened = {int(item["seed"]) for item in screening_records}
    lagged, target = screening_pairs(split.train, config.screening.max_lag, config.data.target)
    for seed in config.training.seeds:
        if seed in completed:
            continue
        write_json(progress, {"status": "running", "current_seed": seed, "completed_seeds": sorted(completed), "expected_seeds": config.training.seeds, "screening_by_seed": screening_records})
        set_seed(seed)
        screening = screen_all_lags(lagged, target, replace(config.screening, seed=seed))
        write_json(output / f"screening_seed_{seed}.json", serializable_screening(screening))
        pd.DataFrame([asdict(item) for item in screening.logs]).to_csv(output / f"screening_steps_seed_{seed}.csv", index=False)
        if seed not in screened:
            screening_records.append({"seed": seed, "seconds": screening.elapsed_seconds, "evaluations": screening.evaluations})
        model = HOGRNN(values.shape[1], config.model.hidden_dim, config.data.horizon, screening.masks, seed, config.model.leak, config.model.initialization_scale, config.model.lag_attention_hidden_dim, config.model.lag_attention_embedding_dim)
        counts = parameter_counts(model)
        result = fit(model, train_xy, validation_xy, test_xy, config.training.epochs, config.training.batch_size, config.training.learning_rate, config.training.patience, seed, config.training.device)
        torch.save(result.state_dict, output / f"checkpoint_seed_{seed}.pt")
        pd.DataFrame(result.history).to_csv(output / f"history_seed_{seed}.csv", index=False)
        row = {"seed": seed, "best_epoch": result.best_epoch, "training_seconds": result.training_seconds, "inference_seconds": result.inference_seconds, **counts, **{key: value for key, value in result.metrics.items() if isinstance(value, float)}, **model.recurrent_diagnostics(), **{f"before_{key}": value for key, value in result.structure_before.items()}, **{f"after_{key}": value for key, value in result.structure_after.items()}}
        rows.append(row)
        completed.add(seed)
        pd.DataFrame(rows).to_csv(raw_path, index=False)
        write_json(output / f"metrics_seed_{seed}.json", result.metrics)
        write_json(output / "partial_summary.json", build_summary(config, values, split, train_xy, validation_xy, test_xy, rows, screening_records, "running"))
    summary = build_summary(config, values, split, train_xy, validation_xy, test_xy, rows, screening_records, "completed")
    write_json(output / "summary.json", summary)
    write_json(progress, {"status": "completed", "current_seed": None, "completed_seeds": sorted(completed), "expected_seeds": config.training.seeds, "screening_by_seed": screening_records})
    return summary
