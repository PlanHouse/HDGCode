from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import numpy as np
import pandas as pd

from .config import DataConfig


@dataclass
class SplitData:
    train: np.ndarray
    validation: np.ndarray
    test: np.ndarray
    minimum: np.ndarray
    scale: np.ndarray


def load_series(config: DataConfig) -> np.ndarray:
    frame = pd.read_csv(Path(config.path))
    if config.columns:
        values = frame[config.columns].to_numpy(dtype=np.float64)
    elif config.format == "matrix":
        numeric = frame.select_dtypes(include=[np.number])
        values = numeric.to_numpy(dtype=np.float64)
    elif config.format == "legacy_stacked":
        numeric = frame.select_dtypes(include=[np.number])
        column = numeric.iloc[:, -1].to_numpy(dtype=np.float64)
        if config.length is None:
            raise ValueError("legacy_stacked requires data.length")
        if len(column) % config.length:
            raise ValueError("stacked series length is not divisible by data.length")
        values = column.reshape((-1, config.length)).T
    else:
        raise ValueError(f"unknown data format: {config.format}")
    if config.length is not None and config.format != "legacy_stacked":
        values = values[-config.length :]
    if values.ndim != 2 or not np.isfinite(values).all():
        raise ValueError("data must be a finite two-dimensional numeric array")
    if not 0 <= config.target < values.shape[1]:
        raise ValueError("target column is out of range")
    return values


def chronological_split(values: np.ndarray, config: DataConfig) -> SplitData:
    n = len(values)
    train_end = int(n * config.train_ratio)
    validation_end = int(n * (config.train_ratio + config.validation_ratio))
    needed = config.sequence_length + config.horizon + 1
    if min(train_end, validation_end - train_end, n - validation_end) < needed:
        raise ValueError("each chronological split must exceed sequence_length + horizon")
    minimum = values[:train_end].min(axis=0)
    maximum = values[:train_end].max(axis=0)
    scale = np.maximum(maximum - minimum, 1e-12)
    transformed = (values - minimum) / scale if config.normalize else values.copy()
    return SplitData(
        train=transformed[:train_end],
        validation=transformed[train_end:validation_end],
        test=transformed[validation_end:],
        minimum=minimum,
        scale=scale,
    )


def make_windows(values: np.ndarray, sequence_length: int, horizon: int, target: int) -> tuple[np.ndarray, np.ndarray]:
    count = len(values) - sequence_length - horizon + 1
    if count <= 0:
        raise ValueError("split is too short for the requested window and horizon")
    x = np.stack([values[i : i + sequence_length] for i in range(count)])
    y = np.stack([values[i + sequence_length : i + sequence_length + horizon, target] for i in range(count)])
    return x.astype(np.float32), y.astype(np.float32)


def screening_pairs(values: np.ndarray, max_lag: int, target: int) -> tuple[np.ndarray, np.ndarray]:
    if len(values) <= max_lag:
        raise ValueError("training split is too short for screening")
    lagged = np.stack([values[max_lag - lag : len(values) - lag] for lag in range(1, max_lag + 1)], axis=1)
    return lagged, values[max_lag:, target]


