from __future__ import annotations

from dataclasses import asdict, dataclass
from time import perf_counter
import numpy as np

from .config import ScreeningConfig
from .reservoir import Family, ReservoirEvaluator, canonical_family, family_key


@dataclass
class SearchStep:
    lag: int
    iteration: int
    operation: str
    current: str
    candidate: str
    current_error: float
    candidate_error: float
    accepted: bool


@dataclass
class ScreeningResult:
    families: list[Family]
    masks: list[np.ndarray]
    weights: list[np.ndarray]
    logs: list[SearchStep]
    evaluations: int
    elapsed_seconds: float


def member_reduction(family: Family) -> list[Family]:
    if len(family) != 1 or len(family[0]) <= 1:
        return []
    member = family[0]
    return [canonical_family([tuple(v for v in member if v != removed) for removed in member])]


def family_reduction(family: Family) -> list[Family]:
    if len(family) <= 1:
        return []
    return sorted({canonical_family(family[:i] + family[i + 1:]) for i in range(len(family))}, key=family_key)


def member_decomposition(family: Family) -> list[Family]:
    candidates = set()
    for index, member in enumerate(family):
        if len(member) <= 1:
            continue
        for removed in member:
            reduced = tuple(v for v in member if v != removed)
            candidates.add(canonical_family(family[:index] + (reduced,) + family[index + 1:]))
    return sorted(candidates, key=family_key)


def _best(evaluator, lag, inputs, target, candidates, fraction):
    scored = [(evaluator.evaluate(lag, inputs, target, candidate, fraction).error, candidate) for candidate in candidates]
    return min(scored, key=lambda item: (item[0], family_key(item[1]))) if scored else None


def screen_lag(evaluator: ReservoirEvaluator, lag: int, inputs: np.ndarray, target: np.ndarray,
               variables: int, config: ScreeningConfig) -> tuple[Family, list[SearchStep]]:
    current = canonical_family([tuple(range(variables))])
    current_error = evaluator.evaluate(lag, inputs, target, current, config.validation_fraction).error
    logs: list[SearchStep] = []
    iteration = 0
    while True:
        iteration += 1
        operations = []
        if len(current) == 1:
            operations.append(("member_reduction", member_reduction(current)))
            reduced = member_reduction(current)
            if reduced:
                operations.append(("family_reduction", family_reduction(reduced[0])))
        else:
            operations.append(("family_reduction", family_reduction(current)))
            operations.append(("member_decomposition", member_decomposition(current)))
        accepted = False
        for operation, candidates in operations:
            chosen = _best(evaluator, lag, inputs, target, candidates, config.validation_fraction)
            if chosen is None:
                continue
            candidate_error, candidate = chosen
            accept = candidate_error <= current_error + config.tolerance
            logs.append(SearchStep(
                lag=lag + 1, iteration=iteration, operation=operation,
                current=family_key(current), candidate=family_key(candidate),
                current_error=current_error, candidate_error=candidate_error, accepted=accept,
            ))
            if accept:
                current, current_error, accepted = candidate, candidate_error, True
                break
        if not accepted:
            break
    return current, logs


def screen_all_lags(lagged: np.ndarray, target: np.ndarray, config: ScreeningConfig) -> ScreeningResult:
    variables = lagged.shape[-1]
    evaluator = ReservoirEvaluator(
        dimension=config.reservoir_dim, variables=variables, seed=config.seed,
        ridge=config.ridge, warmup=config.warmup, input_scale=config.input_scale,
        leak=config.leak, bias=config.bias, capacity_mode=config.capacity_mode,
        recurrent_seed=config.recurrent_seed,
    )
    started = perf_counter()
    families, masks, weights, logs = [], [], [], []
    for lag in range(config.max_lag):
        family, lag_logs = screen_lag(evaluator, lag, lagged[:, lag], target, variables, config)
        result = evaluator.evaluate(lag, lagged[:, lag], target, family, config.validation_fraction)
        families.append(family)
        masks.append(result.input_mask.copy())
        weights.append(result.input_weights.copy())
        logs.extend(lag_logs)
    return ScreeningResult(
        families=families, masks=masks, weights=weights, logs=logs,
        evaluations=len(evaluator.cache), elapsed_seconds=perf_counter() - started,
    )


def serializable_screening(result: ScreeningResult) -> dict:
    return {
        "families": [[list(member) for member in family] for family in result.families],
        "evaluations": result.evaluations,
        "elapsed_seconds": result.elapsed_seconds,
        "logs": [asdict(item) for item in result.logs],
    }

