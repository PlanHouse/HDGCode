from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any
import yaml


@dataclass
class DataConfig:
    path: str
    format: str = "matrix"
    columns: list[str] | None = None
    target: int = 0
    length: int | None = None
    sequence_length: int = 100
    horizon: int = 5
    train_ratio: float = 0.6
    validation_ratio: float = 0.1
    normalize: bool = True


@dataclass
class ScreeningConfig:
    max_lag: int = 3
    reservoir_dim: int = 60
    warmup: int = 50
    ridge: float = 1e-8
    tolerance: float = 5e-7
    seed: int = 2025
    recurrent_seed: int | None = 2025
    input_scale: float = 0.1
    leak: float = 0.05
    bias: float = 1.0
    capacity_mode: str = "member_blocks"
    validation_fraction: float = 0.2


@dataclass
class ModelConfig:
    hidden_dim: int = 150
    leak: float = 0.5
    initialization_scale: float = 0.1
    lag_attention_hidden_dim: int | None = None
    lag_attention_embedding_dim: int = 8


@dataclass
class TrainingConfig:
    epochs: int = 120
    batch_size: int = 128
    learning_rate: float = 1e-3
    patience: int = 20
    seeds: list[int] = field(default_factory=lambda: [2025])
    device: str = "auto"


@dataclass
class ExperimentConfig:
    name: str
    output_dir: str
    data: DataConfig
    screening: ScreeningConfig = field(default_factory=ScreeningConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def load_config(path: str | Path) -> ExperimentConfig:
    path = Path(path).resolve()
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    data = DataConfig(**raw.pop("data"))
    screening = ScreeningConfig(**raw.pop("screening", {}))
    model = ModelConfig(**raw.pop("model", {}))
    training = TrainingConfig(**raw.pop("training", {}))
    config = ExperimentConfig(data=data, screening=screening, model=model, training=training, **raw)
    data_path = Path(config.data.path)
    if not data_path.is_absolute():
        config.data.path = str((path.parent / data_path).resolve())
    output_path = Path(config.output_dir)
    if not output_path.is_absolute():
        config.output_dir = str((path.parent / output_path).resolve())
    validate_config(config)
    return config


def validate_config(config: ExperimentConfig) -> None:
    if config.data.sequence_length < 1 or config.data.horizon < 1:
        raise ValueError("sequence_length and horizon must be positive")
    if not 0 < config.data.train_ratio < 1:
        raise ValueError("train_ratio must be in (0, 1)")
    if not 0 < config.data.validation_ratio < 1 - config.data.train_ratio:
        raise ValueError("validation_ratio must leave a non-empty test split")
    if config.screening.capacity_mode != "member_blocks":
        raise ValueError("capacity_mode must be member_blocks")
    if config.model.lag_attention_hidden_dim is not None and config.model.lag_attention_hidden_dim < 1:
        raise ValueError("lag_attention_hidden_dim must be positive")
    if config.model.lag_attention_embedding_dim < 1:
        raise ValueError("lag_attention_embedding_dim must be positive")
