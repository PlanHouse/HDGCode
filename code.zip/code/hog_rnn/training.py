from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from time import perf_counter
import random
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from .metrics import forecast_metrics


@dataclass
class TrainingResult:
    best_epoch: int
    training_seconds: float
    inference_seconds: float
    history: list[dict[str, float]]
    metrics: dict[str, object]
    structure_before: dict[str, float]
    structure_after: dict[str, float]
    state_dict: dict


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def resolve_device(requested: str) -> torch.device:
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(requested)


def loader(x: np.ndarray, y: np.ndarray, batch_size: int, shuffle: bool, seed: int) -> DataLoader:
    generator = torch.Generator().manual_seed(seed)
    dataset = TensorDataset(torch.from_numpy(x), torch.from_numpy(y))
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, generator=generator)


def _loss(model, data_loader, criterion, device, optimize=None) -> float:
    total, count = 0.0, 0
    for x, y in data_loader:
        x, y = x.to(device), y.to(device)
        if optimize is not None:
            optimize.zero_grad(set_to_none=True)
        prediction = model(x)
        loss = criterion(prediction, y)
        if optimize is not None:
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimize.step()
        total += float(loss.detach()) * len(x)
        count += len(x)
    return total / count


def fit(model: nn.Module, train_xy, validation_xy, test_xy, epochs: int, batch_size: int,
        learning_rate: float, patience: int, seed: int, device_name: str) -> TrainingResult:
    set_seed(seed)
    device = resolve_device(device_name)
    model.to(device)
    train_loader = loader(*train_xy, batch_size, True, seed)
    validation_loader = loader(*validation_xy, batch_size, False, seed)
    test_loader = loader(*test_xy, batch_size, False, seed)
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam((p for p in model.parameters() if p.requires_grad), lr=learning_rate)
    before = model.structure_diagnostics()
    best_loss, best_epoch, best_state, no_improvement = float("inf"), 0, None, 0
    history = []
    started = perf_counter()
    for epoch in range(1, epochs + 1):
        model.train()
        train_loss = _loss(model, train_loader, criterion, device, optimizer)
        model.eval()
        with torch.no_grad():
            validation_loss = _loss(model, validation_loader, criterion, device)
        history.append({"epoch": epoch, "train_mse": train_loss, "validation_mse": validation_loss})
        if validation_loss < best_loss:
            best_loss, best_epoch = validation_loss, epoch
            best_state = deepcopy(model.state_dict())
            no_improvement = 0
        else:
            no_improvement += 1
            if patience > 0 and no_improvement >= patience:
                break
    elapsed = perf_counter() - started
    if best_state is None:
        raise RuntimeError("training did not produce a checkpoint")
    model.load_state_dict(best_state)
    model.eval()
    ys, predictions = [], []
    inference_started = perf_counter()
    with torch.no_grad():
        for x, y in test_loader:
            predictions.append(model(x.to(device)).cpu().numpy())
            ys.append(y.numpy())
    inference_seconds = perf_counter() - inference_started
    metrics = forecast_metrics(np.concatenate(ys), np.concatenate(predictions))
    return TrainingResult(
        best_epoch=best_epoch, training_seconds=elapsed, inference_seconds=inference_seconds,
        history=history, metrics=metrics,
        structure_before=before, structure_after=model.structure_diagnostics(),
        state_dict={k: value.detach().cpu() for k, value in best_state.items()},
    )

